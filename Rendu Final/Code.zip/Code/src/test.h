/**
 * \struct test.h
*/
#ifndef TEST_H
#define TEST_H

// Fonctions de test
void initEcran(SDL_Surface* ecr);
void test_displayPlateau_initMurs();
void test_collision();
void test_addSerpentPlateau();
void test_updateSerpentPlateau();
void free_ecran ();

#endif
