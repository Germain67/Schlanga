//
// Created by lise on 14/05/16.
//

#ifndef SCHLANGA_SCORE_H
#define SCHLANGA_SCORE_H


void Gameover(int compteur, char* mess);

int live_scores ();

#endif //SCHLANGA_SCORE_H
