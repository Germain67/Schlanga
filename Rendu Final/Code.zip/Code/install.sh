#!/bin/bash
#Script to install SDL
sudo apt-get install libsdl1.2-dev libsdl-image1.2 libsdl-image1.2-dev libsdl-ttf2.0-0 libsdl-ttf2.0-dev