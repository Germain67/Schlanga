Comment l'installer?
Lancer le script install.sh pour installer les librairies SDL. 
Ensuite, il suffit de faire make pour compiler le jeu puis ./bin/main pour lancer le jeu.

Comment générer le jeu de test (sans SDL) ?
Il suffit de faire make test

Comment jouer?
Le déplacement dans le menu se fait grâce à l'aide des touches directionnelles HAUT et BAS. 
Pour choisir un menu, il suffit ensuite d'appuyer sur la touche Entrer.
Pour se déplacer dans le jeu, il faut utiliser les flèches directionnelles.