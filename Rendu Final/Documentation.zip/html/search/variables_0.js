var searchData=
[
  ['score',['score',['../main_8c.html#aae13e92096740ad454faa9f84b908961',1,'main.c']]]
];
