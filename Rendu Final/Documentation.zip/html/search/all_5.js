var searchData=
[
  ['main',['main',['../main_8c.html#a51af30a60f9f02777c6396b8247e356f',1,'main.c']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['memscores',['memScores',['../main_8c.html#a313214c174b4a8100f175539e200bb1f',1,'main.c']]]
];
