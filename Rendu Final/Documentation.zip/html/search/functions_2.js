var searchData=
[
  ['showoptions',['showOptions',['../main_8c.html#a4a89658d22be6310bfac147df4e0312e',1,'main.c']]],
  ['showscores',['showScores',['../main_8c.html#a96e28de51dbd290da9309cb12c126bae',1,'main.c']]]
];
