var searchData=
[
  ['score',['score',['../main_8c.html#aae13e92096740ad454faa9f84b908961',1,'main.c']]],
  ['sdl_5ffunctions_2ec',['sdl_functions.c',['../sdl__functions_8c.html',1,'']]],
  ['serpent',['serpent',['../structserpent.html',1,'']]],
  ['showoptions',['showOptions',['../main_8c.html#a4a89658d22be6310bfac147df4e0312e',1,'main.c']]],
  ['showscores',['showScores',['../main_8c.html#a96e28de51dbd290da9309cb12c126bae',1,'main.c']]],
  ['snake_2ec',['snake.c',['../snake_8c.html',1,'']]]
];
